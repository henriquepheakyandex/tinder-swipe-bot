
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.RequestBody;
import org.json.JSONObject;

public class TinderAPI {

    private static final String BASE_URL = "https://api.gotinder.com/v2/";

    public static String getMatches(String token) {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(BASE_URL + "matches")
                .header("X-Auth-Token", token)
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful()) {
                return response.body().string();
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static boolean swipe(String token, String matchId, boolean swipeRight) {
        OkHttpClient client = new OkHttpClient();
        String action = swipeRight ? "like" : "pass";  // "like" para swipe à direita e "pass" para à esquerda

        // Request body para o swipe
        JSONObject jsonBody = new JSONObject();
        jsonBody.put("match_id", matchId);
        jsonBody.put("action", action);

        Request request = new Request.Builder()
                .url(BASE_URL + "matches/" + matchId + "/" + action)
                .header("X-Auth-Token", token)
                .post(RequestBody.create(MediaType.get("application/json"), jsonBody.toString()))
                .build();

        try (Response response = client.newCall(request).execute()) {
            return response.isSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean performAutoSwapWithImage(String token, String matchId, String imageUrl) {
        try {
            // Baixar a imagem do perfil do match
            // Você pode obter a URL da imagem do perfil via API do Tinder.
            
            // Analisar a imagem usando a Google Vision API
            ImageRecognition.analyzeImage(imageUrl);

            // Lógica para decidir o swipe com base nos dados de reconhecimento
            // Se a idade estimada for entre 20 e 30 anos, swipe à direita
            // Caso contrário, swipe à esquerda
            if (/* idade estimada entre 20 e 30 */) {
                return swipe(token, matchId, true);  // Swipe à direita
            } else {
                return swipe(token, matchId, false); // Swipe à esquerda
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
