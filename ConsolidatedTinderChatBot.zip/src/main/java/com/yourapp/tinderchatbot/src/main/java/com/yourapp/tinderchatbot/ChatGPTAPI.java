
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.RequestBody;

public class ChatGPTAPI {

    private static final String OPENAI_API_URL = "https://api.openai.com/v1/completions";
    private static final String OPENAI_API_KEY = "your_openai_api_key"; // Sua chave da API OpenAI

    public static String getChatGptResponse(String prompt) {
        OkHttpClient client = new OkHttpClient();
        String jsonBody = "{ "model": "text-davinci-003", "prompt": "" + prompt + "", "max_tokens": 150 }";

        Request request = new Request.Builder()
                .url(OPENAI_API_URL)
                .header("Authorization", "Bearer " + OPENAI_API_KEY)
                .post(RequestBody.create(MediaType.get("application/json"), jsonBody))
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (response.isSuccessful()) {
                return response.body().string();
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
