
from flask import Flask, render_template, request, send_from_directory, redirect, url_for
import os
from create_files import create_sample_files
from chatgpt_interaction import generate_chatgpt_response
import zipfile

app = Flask(__name__)

# Diretório para salvar arquivos enviados e ZIP gerado
UPLOAD_FOLDER = 'uploads/'
OUTPUT_FOLDER = 'output/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['OUTPUT_FOLDER'] = OUTPUT_FOLDER

# Função para criar o ZIP
def create_zip(zip_name, file_list):
    with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for file in file_list:
            zipf.write(file, os.path.basename(file))
    return zip_name

# Rota para a página principal
@app.route('/')
def index():
    return render_template('index.html')

# Rota para o upload de arquivos
@app.route('/upload', methods=['POST'])
def upload_files():
    if 'file' not in request.files:
        return redirect(request.url)
    file = request.files['file']
    
    if file:
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_path)
        
        # Criar ZIP com o arquivo enviado
        zip_name = os.path.join(app.config['OUTPUT_FOLDER'], 'meuarquivo.zip')
        create_zip(zip_name, [file_path])
        
        # Exemplo de interação com o ChatGPT
        user_message = "Qual o seu projeto favorito?"
        response = generate_chatgpt_response(user_message)
        
        return render_template('index.html', zip_file=zip_name, chatgpt_response=response)

# Rota para baixar o arquivo ZIP gerado
@app.route('/download/<filename>')
def download_file(filename):
    return send_from_directory(app.config['OUTPUT_FOLDER'], filename)

if __name__ == '__main__':
    app.run(debug=True)
