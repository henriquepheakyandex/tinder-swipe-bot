
import openai
import os
from dotenv import load_dotenv

# Carregar variáveis de ambiente do arquivo .env
load_dotenv()

# Configuração da chave da OpenAI
openai.api_key = os.getenv("OPENAI_API_KEY")

def generate_chatgpt_response(message):
    # Gerando uma resposta usando o modelo GPT-3 da OpenAI
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=f"Responda a essa mensagem de forma amigável e interessante: {message}",
        max_tokens=150
    )
    return response.choices[0].text.strip()
