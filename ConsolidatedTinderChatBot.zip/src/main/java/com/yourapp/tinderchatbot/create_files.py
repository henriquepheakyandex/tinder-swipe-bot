
import os

def create_sample_files():
    if not os.path.exists('arquivo1.txt'):
        with open('arquivo1.txt', 'w') as f:
            f.write("Este é o conteúdo do arquivo 1. Vamos adicionar mais texto para expandir.")
    if not os.path.exists('arquivo2.txt'):
        with open('arquivo2.txt', 'w') as f:
            f.write("Este é o conteúdo do arquivo 2. Mais conteúdo para expandir o arquivo e testar.")
    if not os.path.exists('arquivo3.jpg'):
        with open('arquivo3.jpg', 'w') as f:
            f.write("Este é um arquivo de imagem fictício para exemplo. Aumentando o conteúdo.")
